<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>

<div class="container">

	<h2> Où ai je bien pu mettre mon mot de passe ... </h2>
	<h4>
		Pas de soucis, nous vous en envoyons un tout neuf : il nous faut simplement votre email (celui de votre compte) !

	</h4>

	Ajouter un formulaire de mot de passe perdu 
</div>
</html>