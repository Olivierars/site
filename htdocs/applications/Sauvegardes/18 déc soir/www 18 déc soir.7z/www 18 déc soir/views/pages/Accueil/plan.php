<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>

<div class="container">

<legend>
PLan du site 

</legend>

Utile pour le référencement  

</div>
</html>