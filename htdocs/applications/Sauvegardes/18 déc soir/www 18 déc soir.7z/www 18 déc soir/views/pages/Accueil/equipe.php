<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>


<div class="container">
<h2>
L'équipe des patates !!! 

</h2>

</div>
</html>