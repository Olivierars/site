<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>

<div class="container">
	<legend>
		Notre projet en quelques mots
	</legend>

	La mademoiselle patate ca va être à toi !!!  
	<br>
	<div class="texte">
	Lorem ipsum In aliquip enim consequat dolore eiusmod proident reprehenderit laborum reprehenderit do nulla ullamco irure eu pariatur officia culpa veniam nostrud deserunt anim voluptate reprehenderit id sit ut adipisicing quis do. Lorem ipsum Culpa dolore dolore aliquip culpa amet laborum sunt in eiusmod consectetur minim veniam do commodo eu aliqua exercitation tempor nostrud commodo proident sit eu laborum eu aliquip nulla aliquip aute sint nostrud adipisicing Ut dolore dolore aliqua officia exercitation non consectetur voluptate ut commodo officia enim Duis ullamco cillum et consectetur pariatur pariatur laboris in fugiat et enim sint amet ea consectetur proident et nostrud sed in eiusmod sed nisi magna ea nulla minim labore magna consectetur eiusmod amet occaecat deserunt tempor laboris cupidatat non voluptate ut ullamco labore laboris cupidatat in sint eu exercitation est ullamco dolor anim et deserunt ullamco aute adipisicing et in mollit deserunt tempor pariatur aliquip enim magna culpa mollit ad incididunt minim elit qui culpa non in esse id sed aliqua aute nisi do do fugiat irure cupidatat laboris laboris aliqua reprehenderit id adipisicing reprehenderit cillum fugiat aliquip veniam ea do laboris dolore consectetur magna aliqua.

	</div>


</div>

</html>



