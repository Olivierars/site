<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<div class="container">
	<legend>
		Foire aux questions 
	</legend>
	
	N'hésitez pas à nous <a href="<?php echo site_url('Accueil/Contact') ?>">contacter</a>, il n'y a pas de question bête ! Nous vous réponderons avec plaisir  

</div>

</div>
</html>