<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>

<div class="container">
	
	<h1>Mes derniers messages</h1>
	- pourvoir consulter les messages <br>
	- pourvoir répondre à un message <br>
	- pouvoir écrire un nouveau message <br>

--> trouver un tuto qui va bien  :)

</div>

</html>