<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>

<div class="container">

	<p>
		Votre message nous est bien parvenu !
	</p>

	<p>
		<?php echo anchor('Accueil','Retour à l\'accueil'); ?>
	</p>

</div>
</html>