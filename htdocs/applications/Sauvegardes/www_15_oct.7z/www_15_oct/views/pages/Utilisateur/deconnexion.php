<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>

<div class="container">

	Vous avez été déconnecté :( 
	A bientot 

</div> 

</html>