<!DOCTYPE html> 
<html lang="fr">

<div class="container">

	Bienvenue : vous êtes maintenant inscrit !

	<?php echo anchor('Utilisateur/connexion','Connectez vous !'); ?>
<!-- 	<a href="<?php echo site_url('Utilisateur/connexion') ?>">Connectez vous ! </a>
 -->

</div>


</html>