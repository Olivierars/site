<div class="navbar navbar-inverse navbar-fixed-bottom" role="navigation">
	<div class="container">
		<div class="navbar-text pull-left">
			<p>&copy; 2015 - Anne KEISSER & Olivier ARSAC 
				<?php echo str_repeat("&nbsp;", 30); ?>
				<?php echo anchor('Accueil/plan','Plan du site'); ?> 
				<?php echo str_repeat("&nbsp;", 10); ?>
				<?php echo anchor('Accueil/reglement','Reglement de l\'association '); ?> 
				<?php echo str_repeat("&nbsp;", 10); ?>
				<?php echo anchor('Accueil/liens_utiles','Liens utiles '); ?> 

			</p>
		</div>

		<div class="navbar-text pull-right">
			<a href="#"><i class="fa fa-facebook-square fa-2x"></i></a>
			<a href="#"><i class="fa fa-twitter fa-2x"></i></a>
			<a href="#"><i class="fa fa-google-plus fa-2x"></i></a>
		</div>
	</div>
</div>





<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="/assets/js/bootstrap.min.js"></script>
</body>
</html>