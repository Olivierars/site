<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<div class="container">

	<h2>Réglement </h2>
	On n'est pas la pour rigoler

</div>

</div>

</html>