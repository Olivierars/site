<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>

<div class="container">

<h2>
PLan du site 
</h2>

Utile pour le référencement  

</div>
</html>