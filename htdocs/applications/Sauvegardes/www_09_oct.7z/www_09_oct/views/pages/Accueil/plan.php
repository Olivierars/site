<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>

<div class="container">
PLan du site 

Utile pour le référencement  

</div>
</html>