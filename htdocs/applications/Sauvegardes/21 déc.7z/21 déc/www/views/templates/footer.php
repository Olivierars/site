<div id="footer" class="navbar navbar-inverse navbar-fixed-bottom" role="navigation">
	<div class="container">
		<div class="navbar-text pull-left">
			<p>&copy; 2015 - Anne KEISSER & Olivier ARSAC 
				<?php echo str_repeat("&nbsp;", 30); ?>
				<?php echo anchor('Accueil/plan','Plan du site'); ?> 
				<?php echo str_repeat("&nbsp;", 10); ?>
				<?php echo anchor('Accueil/reglement','Reglement de l\'association '); ?> 
				<?php echo str_repeat("&nbsp;", 10); ?>
				<?php echo anchor('Accueil/liens_utiles','Liens utiles '); ?> 

			</p>
		</div>

		<div class="navbar-text pull-right">
			<a href="https://www.facebook.com/Moveforall/?sk=timeline&app_data" target="_blank"><i class="fa fa-facebook-square fa-2x"></i></a>
			<a href="#" target="_blank"><i class="fa fa-twitter fa-2x"></i></a>
			<a href="#" target="_blank"><i class="fa fa-google-plus fa-2x"></i></a>
		</div>
	</div>
</div>





<!-- jQuery -->
<!-- <script src="/assets/js/jquery.js"></script>
 --><!-- A MODIFIER LORS DU PASSAGE EN PROD pour ne plus l'avoir en local -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>


<!-- Lien faire les fichiers js  -->
<script src="/assets/js/test.js"></script>
<script src="assets/js/star-rating.min.js" type="text/javascript"></script>
<!-- AJAX  --> 
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"></script>


<!-- Bootstrap -->
<script src="/assets/js/bootstrap.js"></script>

</body>
</html>