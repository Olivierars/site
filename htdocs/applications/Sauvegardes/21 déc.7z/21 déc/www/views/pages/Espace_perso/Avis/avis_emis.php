<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>

<div class="container">

	<ul class="nav nav-pills">
	  <li role="presentation"><a href="<?php echo site_url('Espace_perso/Avis/laisser_avis') ?>">Laisser un avis</a></li>
	  <li role="presentation"><a href="<?php echo site_url('Espace_perso/Avis/avis_recu') ?>">Mes avis recus</a></li>
	  <li role="presentation" class="active"><a href="<?php echo site_url('Espace_perso/Avis/avis_emis') ?>">Mes avis emis</a></li>
	</ul>

	<h3>Mes avis émis</h3>	
		
</div>

</html>