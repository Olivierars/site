<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>

<div class="container">

<legend>
Liens utiles 

</legend>

</div>
</html>